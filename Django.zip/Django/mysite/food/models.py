from django.db import models
from django.contrib.auth.models import User

# Create your models here.
    
class Item(models.Model):
    def __str__(self):
        return self.item_name
    user_name = models.ForeignKey(User , on_delete=models.CASCADE, default=1)
    prod_code = models.IntegerField(default=100)
    for_user = models.CharField(max_length=200, default='Alex')
    item_name = models.CharField(max_length=200)
    item_desc = models.CharField(max_length=300)
    item_price = models.IntegerField()
    item_image = models.CharField(max_length=5000, default='https://starinfinitefood.com/wp-content/uploads/2017/01/photo-1446034730750-a0b64d06ad13.jpeg')
    

class History(models.Model):
    def __str__ (self):
        return str(
            (
                self.prod_ref,
                self.user_name,
                self.item_name,
                self.op_type
            )
        )
    
    user_name = models.CharField(max_length=200)
    prod_ref = models.IntegerField(default=100)
    item_name = models.CharField(max_length=200)
    op_type = models.CharField(max_length=100)