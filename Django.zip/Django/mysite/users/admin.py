from django.contrib import admin
from users.models import Profile
from users.models import CustOrders, CusRatingFeedback

# Register your models here.
admin.site.register(Profile)
admin.site.register(CustOrders)
admin.site.register(CusRatingFeedback)